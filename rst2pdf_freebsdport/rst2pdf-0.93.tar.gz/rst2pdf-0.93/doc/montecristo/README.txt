This is an example of fancier typography.

To build it, get the scriptina font from http://www.dafont.com/scriptina.font
and run::

  rst2pdf montecristo.rst -s montecristo.sheet

