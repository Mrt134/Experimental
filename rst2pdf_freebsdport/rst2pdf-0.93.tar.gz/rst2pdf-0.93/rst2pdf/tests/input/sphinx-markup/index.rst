Sphinx Test Document
====================

This is a test document

.. toctree::

   module
   inline
   paragraph
   code
   misc
   index-gen

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

