.. module:: parrot
   :platform: Unix, Windows
   :synopsis: Analyze and reanimate dead parrots.

.. function:: spam(eggs)
              ham(eggs)

   Spam or ham the foo.
