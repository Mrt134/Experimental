.. code-block:: python

   A=3
   
.. highlightlang:: python

::
    
   A=3

   
