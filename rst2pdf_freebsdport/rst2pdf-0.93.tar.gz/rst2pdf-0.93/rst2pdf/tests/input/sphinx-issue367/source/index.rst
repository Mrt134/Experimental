.. german test documentation master file, created by
   sphinx-quickstart on Wed Sep 15 19:32:20 2010.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to german test's documentation!
=======================================

Contents:

.. toctree::
   :maxdepth: 2

   misc

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

