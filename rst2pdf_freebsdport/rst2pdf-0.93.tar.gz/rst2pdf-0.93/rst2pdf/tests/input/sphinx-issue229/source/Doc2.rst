
=====
Doc2
=====

.. contents::
   :local:

--------------
Section Beta
--------------

Some text.

------------
Section One
------------

Some more text.
