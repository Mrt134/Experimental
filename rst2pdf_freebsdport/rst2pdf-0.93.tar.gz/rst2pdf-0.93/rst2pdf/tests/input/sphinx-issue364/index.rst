Index 1

:term:`term1`

.. glossary::

    term1
        A term in 1st place

    term2
        A term in 2nd place

:term:`term1` and :term:`term2` link to the glossary

